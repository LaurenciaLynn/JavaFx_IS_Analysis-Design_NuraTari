module projectBadLEC {
	exports projectBadLEC;
	requires javafx.graphics;
	requires javafx.controls;
	requires java.scripting;
	requires java.sql;
	requires javafx.base;
	
}
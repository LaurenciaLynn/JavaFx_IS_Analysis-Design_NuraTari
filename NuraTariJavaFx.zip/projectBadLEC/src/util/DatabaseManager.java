package util;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {

    private final String USERNAME = "root";
    private final String PASSWORD = "";
    private final String DATABASE = "nuratari";
    private final String HOST = "localhost:3306";
    private final String URL = String.format("jdbc:mysql://%s/%s", HOST, DATABASE);

    private static DatabaseManager instance;
    private Connection con;
    private Statement st;
    private ResultSet rs;

    public static DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    public Connection getConnection() {
        try {
            if (con == null || con.isClosed()) {
                con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }

    public ResultSet execQuery(String query) {
        try {
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public void execUpdate(String query) {
        try {
            st = getConnection().createStatement();
            st.executeUpdate(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void closeResources() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
        
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private DatabaseManager() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
package projectBadLEC;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Calculator {

    private StringBuilder input = new StringBuilder();
    private StringBuilder history = new StringBuilder();  
    private Label displayLabel;
    private Label historyLabel;

    Image backgroundImage = new Image("file:Migell.jpg");
    BackgroundImage background = new BackgroundImage(
            backgroundImage,
            BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.DEFAULT,
            new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));

    public void displayCalculator() {
        Stage calculatorStage = new Stage();
        calculatorStage.setTitle("Calculator");

        GridPane grid = new GridPane();
        grid.setHgap(7);
        grid.setVgap(7);
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setAlignment(Pos.BOTTOM_LEFT);

        displayLabel = new Label();
        displayLabel.setMinHeight(30);
        displayLabel.setStyle("-fx-border-color: white;");
        grid.add(displayLabel, 0, 0, 4, 1);

        historyLabel = new Label("History:");
        grid.add(historyLabel, 0, 1, 4, 1);

        String[][] buttonLabels = {
                {"7", "8", "9", "/"},
                {"4", "5", "6", "*"},
                {"1", "2", "3", "-"},
                {"0", "C", "=", "+"},
                {"<-", ".", "(", ")", "Clear"}};
        for (int row = 0; row < buttonLabels.length; row++) {
            HBox hbox = new HBox(10);
            hbox.setAlignment(Pos.BOTTOM_LEFT);
            for (int col = 0; col < buttonLabels[row].length; col++) {
                Button button = new Button(buttonLabels[row][col]);
                button.setMinSize(40, 40);
                button.setOnAction(e -> handleButtonClick(button.getText()));
                hbox.getChildren().add(button);
            }
            grid.add(hbox, 0, row + 2, 4, 1);
        }

        Scene scene = new Scene(grid, 400, 711);
        scene.setFill(null);
        grid.setBackground(new Background(background));  // Use the class-level background
        calculatorStage.setScene(scene);
        calculatorStage.setResizable(false);
        calculatorStage.show();
    }

    private void handleButtonClick(String buttonText) {
        switch (buttonText) {
            case "=":
                calculate();
                break;
            case "C":
                clear();
                break;
            case "Clear":
                clearHistory();
                break;
            case "<-":
                delete();
                break;
            default:
                input.append(buttonText);
                displayLabel.setText(input.toString());
        }
    }

    private void calculate() {
        try {
            String result = String.valueOf(eval(input.toString()));
            history.append(input.toString()).append(" = ").append(result).append("\n");
            displayLabel.setTextFill(Color.BLACK);
            displayLabel.setText(result);
            historyLabel.setText("History:\n" + history.toString());
            clear();
        } catch (Exception e) {
            displayLabel.setText("Error");
            displayLabel.setTextFill(Color.BLACK);
        }
    }

    private void clear() {
        input.setLength(0);
        displayLabel.setText("");
    }

    private void clearHistory() {
        history.setLength(0);
        historyLabel.setText("History:");
    }

    private void delete() {
        if (input.length() > 0) {
            input.deleteCharAt(input.length() - 1);
            displayLabel.setText(input.toString());
        }
    }

    private double eval(String expression) {
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");

        try {
            Object result = engine.eval(expression);
            if (result instanceof Number) {
                return ((Number) result).doubleValue();
            } else {
                throw new RuntimeException("Invalid result type");
            }
        } catch (ScriptException e) {
            throw new RuntimeException("Error evaluating expression", e);
        }
    }
}
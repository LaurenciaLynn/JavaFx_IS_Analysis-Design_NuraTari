package projectBadLEC;

import java.util.Objects;

public class FormRegistrasiKampanye {
    private String idFormRegistrasiKampanye;
    private String username;
    private String idKampanye;
    private String alasan;

    public FormRegistrasiKampanye() {
        this.idFormRegistrasiKampanye = idFormRegistrasiKampanye;
        this.username = username;
        this.idKampanye = idKampanye;
        this.alasan = alasan;
    }

    public String getIdFormRegistrasiKampanye() {
        return idFormRegistrasiKampanye;
    }

    public void setIdFormRegistrasiKampanye(String idFormRegistrasiKampanye) {
        this.idFormRegistrasiKampanye = idFormRegistrasiKampanye;
    }



    public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getIdKampanye() {
        return idKampanye;
    }

    public void setIdKampanye(String idKampanye) {
        this.idKampanye = idKampanye;
    }

    public String getAlasan() {
        return alasan;
    }

    public void setAlasan(String alasan) {
        this.alasan = alasan;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FormRegistrasiKampanye that = (FormRegistrasiKampanye) o;
        return Objects.equals(idFormRegistrasiKampanye, that.idFormRegistrasiKampanye) &&
                Objects.equals(username, that.username) &&
                Objects.equals(idKampanye, that.idKampanye) &&
                Objects.equals(alasan, that.alasan);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFormRegistrasiKampanye, username, idKampanye, alasan);
    }
}
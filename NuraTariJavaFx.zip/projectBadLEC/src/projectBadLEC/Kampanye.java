package projectBadLEC;

import java.time.LocalDate;
import java.util.Date;

public class Kampanye {
    private String IDkampanye;
    private String namakampanye;
    private int kapasitas;
    private String deskripsiKampanye;
    private LocalDate tanggal;
    private String lokasi;

    
    public Kampanye(String IDkampanye, String namakampanye, int kapasitas, String deskripsiKampanye, LocalDate tanggal, String lokasi) {
        this.IDkampanye = IDkampanye;
        this.namakampanye = namakampanye;
        this.kapasitas = kapasitas;
        this.deskripsiKampanye = deskripsiKampanye;
        this.tanggal = tanggal;
        this.lokasi = lokasi;
    }

   
    public String getIDkampanye() {
        return IDkampanye;
    }

    public void setIDkampanye(String IDkampanye) {
        this.IDkampanye = IDkampanye;
    }

    public String getNamakampanye() {
        return namakampanye;
    }

    public void setNamakampanye(String namakampanye) {
        this.namakampanye = namakampanye;
    }

    public int getKapasitas() {
        return kapasitas;
    }

    public void setKapasitas(int kapasitas) {
        this.kapasitas = kapasitas;
    }

    public String getDeskripsiKampanye() {
        return deskripsiKampanye;
    }

    public void setDeskripsiKampanye(String deskripsiKampanye) {
        this.deskripsiKampanye = deskripsiKampanye;
    }

    public LocalDate getTanggal() {
        return tanggal;
    }

    public void setTanggal(LocalDate tanggal) {
        this.tanggal = tanggal;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }
}


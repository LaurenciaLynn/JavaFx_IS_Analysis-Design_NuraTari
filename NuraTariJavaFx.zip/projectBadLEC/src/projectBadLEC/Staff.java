package projectBadLEC;

public class Staff {
    private String staffId;
    private String name;
    private String[] passwords = {"gueganteng", "ngikngok", "gakmauah", "walauwee"};

    public Staff(String staffId, String name) {
        this.staffId = staffId;
        this.name = name;
    }

    public String getStaffId() {
        return staffId;
    }

    public String getName() {
        return name;
    }

    public boolean isValidCredentials(String password) {
        return passwords[getStaffIndex()] != null && passwords[getStaffIndex()].equals(password);
    }

    private int getStaffIndex() {
        String[] staffIds = {"ST001", "ST002", "ST003", "ST004"};
        for (int i = 0; i < staffIds.length; i++) {
            if (staffIds[i].equals(staffId)) {
                return i;
            }
        }
        return -1;
    }
}

package projectBadLEC;

public class Forum {
    private String idForum;
    private String username;
    private String isi;

    
    public Forum() {
       
    }

    public Forum(String idForum, String username, String isi) {
        this.idForum = idForum;
        this.username = username;
        this.isi = isi;
    }


    public String getIdForum() {
        return idForum;
    }

    public void setIdForum(String idForum) {
        this.idForum = idForum;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIsi() {
        return isi;
    }

    public void setIsi(String isi) {
        this.isi = isi;
    }


    public String toString() {
        return "Forum{" +
                "idForum='" + idForum + '\'' +
                ", username='" + username + '\'' +
                ", isi='" + isi + '\'' +
                '}';
    }
}
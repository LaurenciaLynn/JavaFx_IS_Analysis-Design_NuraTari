package projectBadLEC;

import javafx.animation.Timeline;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.util.Duration;



import util.DatabaseManager;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class NuratariApp extends Application {
    private List<Customer> customers = new ArrayList<>();
    private List<Kampanye> kampanyeList = new ArrayList<>();
    private TableView<Kampanye> kampanyeTable = new TableView<>();
    private Stage primaryStage;
    private ObservableMap<String, String> customerCredentials = FXCollections.observableHashMap();
    private Map<String, List<String>> searchHistory = new HashMap<>();
    private String currentUser; 
    private Staff currentStaff;
    private int charIndex = 0;
    Connection connection;
    
    
    DatabaseManager connect = DatabaseManager.getInstance();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Nuratari App");
        showSignInPage();
    }
    
    private boolean isUsernameExists(String username) {
        for (Customer customer : customers) {
            if (customer.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isEmailExists(String email) {
        for (Customer customer : customers) {
            if (customer.getEmail().equals(email)) {
                return true;
            }
        }
        return false;
    }

    
    private void showRegisterPage() {
        GridPane grid = new GridPane();
        Image backgroundImage = new Image("file:Customerregisterpage.png"); 
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        grid.setBackground(new Background(background));
        grid.setAlignment(javafx.geometry.Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Scene scene = new Scene(grid, 1000, 700);
        primaryStage.setScene(scene);

        TextField nameTextField = new TextField();
        TextField phoneTextField = new TextField();
        TextField emailTextField = new TextField();
        TextField usernameTextField = new TextField();
        PasswordField passwordField = new PasswordField();
        PasswordField rePasswordField = new PasswordField();
        Button registerButton = new Button("Register");
        Button backButton = new Button("Back");

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameTextField, 1, 0);
        grid.add(new Label("Phone:"), 0, 1);
        grid.add(phoneTextField, 1, 1);
        grid.add(new Label("Email:"), 0, 2);
        grid.add(emailTextField, 1, 2);
        grid.add(new Label("Username:"), 0, 3);
        grid.add(usernameTextField, 1, 3);
        grid.add(new Label("Password:"), 0, 4);
        grid.add(passwordField, 1, 4);
        grid.add(new Label("Re-enter Password:"), 0, 5);
        grid.add(rePasswordField, 1, 5);
        grid.add(registerButton, 1, 6);
        grid.add(backButton, 0, 6);
        
       

        backButton.setOnAction(e -> showSignInPage());

        registerButton.setOnAction(e -> {
            String name = nameTextField.getText();
            String phone = phoneTextField.getText();
            String email = emailTextField.getText();
            String username = usernameTextField.getText();
            String password = passwordField.getText();
            String rePassword = rePasswordField.getText();

            if (name.isEmpty() || phone.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty() || rePassword.isEmpty()) {
                showAlert("Please fill in all fields!", "");
            } else if (phone.length() != 12 || !phone.matches("\\d+")) {
                showAlert("Invalid phone number! It must be 12 digits and contain only numbers.", "");
            } else if (!email.endsWith(".com")) {
                showAlert("Invalid email! It must end with '.com'.", "");
            } else if (isUsernameExists(username)) {
                showAlert("Username already exists! Please choose another one.", "");
            } else if (isEmailExists(email)) {
                showAlert("Email already exists! Please choose another one.", "");
            } else if (password.length() < 8) {
                showAlert("Password length minimum 8!", "");
            } else if (!password.equals(rePassword)) {
                showAlert("Password doesn't match!", "");
            } else {
                
                insertCustomerData(username, username, email, phone, password);

                customerCredentials.put(username, password);
                showAlert("User account created", "");
                clearFields(nameTextField, phoneTextField, emailTextField, usernameTextField, passwordField, rePasswordField);
                showRegisterPage();
            }
        });

        primaryStage.show();
    }
    
    private void openCalculator() {
        Calculator calculator = new Calculator();
        calculator.displayCalculator();  
    }
    
    public void insertCustomerData(String username, String name, String email, String phone, String password) {
    	String query = String.format(
                "INSERT INTO customer(Username, Name, Phone, Email, Password) " +
                        "VALUES ('%s', '%s', '%s', '%s', '%s')", username, name, phone, email, password);
        connect.execUpdate(query);
	}
    

   


    private void showSignInPage() {

    	
    	
        GridPane grid = new GridPane();
        
        Image backgroundImage = new Image("file:SIgn In.jpg"); 
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        grid.setBackground(new Background(background));

        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(0);
        grid.setPadding(new Insets(25, 25, 25, 25));
        
        


        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPercentWidth(10);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPercentWidth(10);
        ColumnConstraints col3 = new ColumnConstraints();
        col3.setPercentWidth(10);
        ColumnConstraints col4 = new ColumnConstraints();
        col3.setPercentWidth(10);
        grid.getColumnConstraints().addAll(col1, col2, col3,col4);


        RowConstraints row1 = new RowConstraints();
        row1.setPercentHeight(10);
        RowConstraints row2 = new RowConstraints();
        row2.setPercentHeight(10);
        grid.getRowConstraints().addAll(row1, row2);

        Scene scene = new Scene(grid, 1000, 700);
        primaryStage.setScene(scene);

        Button registerButton = new Button("Register");
        Button customerButton = new Button("Customer");
        Button staffButton = new Button("Staff");

        Text Copyright = new Text("Nuratari by Michael Sean , Maria Angelina, and Laurencia Lynn");
        Copyright.setFont(Font.font("SansSerif", FontWeight.BOLD, 15));
        
      

        grid.add(Copyright, 0, 0, 4, 1);
        GridPane.setHalignment(Copyright, HPos.CENTER);
        GridPane.setValignment(Copyright, VPos.CENTER);  
        grid.add(registerButton, 0, 1);
        grid.add(customerButton, 1, 1);
        grid.add(staffButton, 2, 1);
        
        Button exitButton = new Button("Exit");
        grid.add(exitButton, 3, 1);

        GridPane.setHalignment(registerButton, HPos.CENTER);
        GridPane.setHalignment(customerButton, HPos.CENTER);
        GridPane.setHalignment(staffButton, HPos.CENTER);

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(Copyright.fillProperty(), Color.RED)),
                new KeyFrame(Duration.seconds(5), new KeyValue(Copyright.fillProperty(), Color.GREEN)),
                new KeyFrame(Duration.seconds(10), new KeyValue(Copyright.fillProperty(), Color.BLUE)),
                new KeyFrame(Duration.seconds(15), new KeyValue(Copyright.fillProperty(), Color.RED))
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        registerButton.setOnAction(e -> showRegisterPage());

        customerButton.setOnAction(e -> showCustomerSignInPage());
        staffButton.setOnAction(e -> showStaffSignInPage());
        exitButton.setOnAction(e -> System.exit(0));
        primaryStage.show();
    }
    

    private void showMainPage() {
    	
        GridPane grid = new GridPane();
        Image backgroundImage = new Image("file:customermainmenu.png"); 
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        grid.setBackground(new Background(background));
        grid.setAlignment(javafx.geometry.Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Scene scene = new Scene(grid, 1000, 700);
        primaryStage.setScene(scene);


        Button kampanyeButton = new Button("Kampanye Pelestarian");
        Button petaButton = new Button("Peta Lingkungan");
        Button communityButton = new Button("Community");
        Button profileButton = new Button("Profile");
        Button backButton = new Button("Back");
        


        grid.add(kampanyeButton, 1, 0);
        grid.add(petaButton,2 , 0);
        grid.add(communityButton, 3, 0);
        grid.add(profileButton, 4, 0);
        grid.add(backButton, 0, 0);


        kampanyeButton.setOnAction(e -> showKampanyeListPage());
        petaButton.setOnAction(e -> showPetaLingkunganPage());
        communityButton.setOnAction(e -> showCommunityPage());
        profileButton.setOnAction(e -> showCustomerProfile());
        backButton.setOnAction(e -> showSignInPage());

        primaryStage.show();
    }
    
    private void showCommunityPage() {
        GridPane grid = new GridPane();
        Image backgroundImage = new Image("file:community.png"); 
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        grid.setBackground(new Background(background));
        grid.setAlignment(javafx.geometry.Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Scene scene = new Scene(grid, 1000, 700);
        primaryStage.setScene(scene);

        ListView<String> forumListView = new ListView<>();
        TextField forumTextArea = new TextField();
        forumTextArea.setPromptText("Share your experience...");

        Button addToForumButton = new Button("Submit");
        Button backButton = new Button("Back");

        addToForumButton.setOnAction(e -> handleAddToForumAction(forumTextArea.getText(), forumListView));
        backButton.setOnAction(e -> showMainPage());

        grid.add(forumListView, 0, 0, 2, 1);
        grid.add(forumTextArea, 0, 1, 2, 1);
        grid.add(addToForumButton, 0, 2);
        grid.add(backButton, 1, 2);

        displayForumPosts(forumListView);

        primaryStage.show();
    }
    
    private void handleAddToForumAction(String forumPost, ListView<String> forumListView) {
        if (forumPost.isEmpty()) {
            showAlert("", "Please fill text box to submit forum");
            return;  
        }

        Random random = new Random();
        String idForum = "FRK" + random.nextInt(10) + random.nextInt(10) + random.nextInt(10);
        String username = currentUser;
        saveForumPostToDatabase(idForum, username, forumPost);

        showAlert("Forum Ditambahkan", "Forum anda berhasil di tambahkan!");
        displayForumPosts(forumListView);
    }
    
    private void saveForumPostToDatabase(String idForum, String username, String forumPost) {
        String query = "INSERT INTO forum (idForum, username, isi) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connect.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, idForum);
            preparedStatement.setString(2, username);
            preparedStatement.setString(3, forumPost);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void displayForumPosts(ListView<String> forumListView) {
        String query = "SELECT * FROM forum";
        try (PreparedStatement preparedStatement = connect.getConnection().prepareStatement(query)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            forumListView.getItems().clear();
            while (resultSet.next()) {
                String username = resultSet.getString("username");
                String isi = resultSet.getString("isi");
                String displayText = username + ": " + isi;
                forumListView.getItems().add(displayText);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    

    
    
    
    
    
    
    
    
    private void showKampanyeListPage() {
   	 GridPane grid = new GridPane();
   	 Image backgroundImage = new Image("file:CustomerKampanye.png"); 
     BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
     grid.setBackground(new Background(background));
   	    grid.setAlignment(javafx.geometry.Pos.CENTER);
   	    grid.setHgap(10);
   	    grid.setVgap(10);
   	    grid.setPadding(new Insets(25, 25, 25, 25));

   	    Scene scene = new Scene(grid, 1000, 700);
   	    primaryStage.setScene(scene);
   	    primaryStage.setTitle("Campaign List");
   	    VBox layout = new VBox(10);

   	    Label titleLabel = new Label("Campaign List");
   	    grid.add(titleLabel, 0, 0, 2, 1);

   	    ListView<String> kampanyeListView = new ListView<>();
   	    kampanyeListView.getItems().clear();

   	    List<Kampanye> kampanyeList = getKampanyeListFromDatabase();

   	    for (Kampanye kampanye : kampanyeList) {
   	        kampanyeListView.getItems().add(kampanye.getNamakampanye());
   	    }

   	    grid.add(kampanyeListView, 0, 1, 2, 4);

   	    Button backButton = new Button("Back");
   	    Button volunteerButton = new Button("Volunteer");

   	    backButton.setOnAction(e -> showMainPage());

   	    volunteerButton.setOnAction(e -> {
   	        String selectedKampanyeName = kampanyeListView.getSelectionModel().getSelectedItem();
   	        if (selectedKampanyeName != null) {
   	        	fillFormRegistrationKampanye(selectedKampanyeName);
   	        } else {
   	            showAlert("Choose campaign", "Choose a campaign to see details");
   	        }
   	    });

   	    grid.add(backButton, 0, 6);
   	    grid.add(volunteerButton, 1, 6);

   	    primaryStage.show();
   	}
   	
   
   private List<Kampanye> getKampanyeListFromDatabase() {
	   kampanyeList.clear();

       
       try (Statement statement = connect.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM kampanye")) {

           while (resultSet.next()) {
               String id = resultSet.getString("IDkampanye");
               String nama = resultSet.getString("namakampanye");
               int kapasitas = resultSet.getInt("kapasitas");
               String deskripsi = resultSet.getString("deskripsiKampanye");
               LocalDate tanggal = resultSet.getDate("tanggal").toLocalDate();
               String lokasi = resultSet.getString("lokasi");

               Kampanye kampanye = new Kampanye(id, nama, kapasitas, deskripsi, tanggal, lokasi);
               kampanyeList.add(kampanye);
           }

       } catch (SQLException e) {
           e.printStackTrace();
       }

       return kampanyeList;
   }
   
   
   private void fillFormRegistrationKampanye(String selectedKampanyeName) {
   	Kampanye selectedKampanye = getKampanyeByName(selectedKampanyeName);
   	 if (selectedKampanye != null) {
   	        GridPane grid = new GridPane();
   	        Image backgroundImage = new Image("file:formregisterkampanye.png"); 
   	        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
   	        grid.setBackground(new Background(background));
   	        grid.setAlignment(javafx.geometry.Pos.CENTER);
   	        grid.setHgap(10);
   	        grid.setVgap(10);
   	        grid.setPadding(new Insets(25, 25, 25, 25));

   	        Scene scene = new Scene(grid, 1000, 700);
   	        primaryStage.setScene(scene);
   	        primaryStage.setTitle("Campaign Registration Form");

   	        
   	        addLabelToLayout(grid, "Campaign Name: " + selectedKampanye.getNamakampanye());
   	        addLabelToLayout(grid, "Description: " + selectedKampanye.getDeskripsiKampanye());
   	        addLabelToLayout(grid, "Date: " + selectedKampanye.getTanggal());
   	        addLabelToLayout(grid, "Location: " + selectedKampanye.getLokasi());
   	        addLabelToLayout(grid, "Capacity: " + selectedKampanye.getKapasitas());

   	        TextField alasanTextField = new TextField();
   	        Button volunteerMeButton = new Button("Sign me up!");

   	        volunteerMeButton.setOnAction(e -> handleVolunteerMeAction(selectedKampanye, alasanTextField.getText().trim()));

   	        grid.add(new Label("Reason:"), 0, 6);
   	        grid.add(alasanTextField, 1, 6);
   	        grid.add(volunteerMeButton, 2, 6);

   	        Button backButton = new Button("Back");
   	        backButton.setOnAction(e -> showKampanyeListPage());

   	        grid.add(backButton, 0, 8);

   	        primaryStage.show();
   	    } else {
   	        showAlert("Campaign not found!", "");
   	    }
   }
   
   private void handleVolunteerMeAction(Kampanye selectedKampanye, String alasan) {     
       Random random = new Random();      
       String idFormRegistrasiKampanye = "FRK" + random.nextInt(10)+ random.nextInt(10)+ random.nextInt(10);
       saveVolunteerRegistrationToDatabase(idFormRegistrasiKampanye, selectedKampanye, alasan);
   }
   
   private void saveVolunteerRegistrationToDatabase(String idFormRegistrasiKampanye, Kampanye selectedKampanye, String alasan) {
       try (Connection connection = connect.getConnection()) {
           String query = "INSERT INTO formregistrasikampanye (idformregistrasikampanye, username, idKampanye, alasan) VALUES (?, ?, ?, ?)";

           try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
               preparedStatement.setString(1, idFormRegistrasiKampanye);
               preparedStatement.setString(2, currentUser);
               preparedStatement.setString(3, selectedKampanye.getIDkampanye());
               preparedStatement.setString(4, alasan);

               int rowsInserted = preparedStatement.executeUpdate();

               if (rowsInserted > 0) {
                  
               } else {
                   
               }
           }
       } catch (SQLException e) {
           e.printStackTrace();
       }
   }


   

    
    private void addLabelToLayout(GridPane layout, String text) {
        Label label = new Label(text);
        layout.add(label, 0, layout.getRowCount());
    }
    
    private Kampanye getKampanyeByName(String kampanyeName) {
        for (Kampanye kampanye : kampanyeList) {
            if (kampanye.getNamakampanye().equals(kampanyeName)) {
                return kampanye;
            }
        }
        return null;
    }
    private void showCustomerProfile() {
        String query = "SELECT * FROM customer WHERE Username = ?";
        try (PreparedStatement preparedStatement = connect.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, currentUser);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String name = resultSet.getString("Name");
                String email = resultSet.getString("Email");
                String phone = resultSet.getString("Phone");

                Label usernameLabel = new Label("Username: " + currentUser);
                Label nameLabel = new Label("Name: " + name);
                Label emailLabel = new Label("Email: " + email);
                Label phoneLabel = new Label("Phone: " + phone);

                PasswordField passwordField = new PasswordField();
                passwordField.setText(resultSet.getString("Password"));

                ToggleButton showPasswordButton = new ToggleButton("View Password");

                Button backButton = new Button("Back");
                Button editButton = new Button("Edit");

                GridPane grid = new GridPane();
                Image backgroundImage = new Image("file:profile.png"); 
                BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
                grid.setBackground(new Background(background));
                grid.setAlignment(Pos.CENTER);
                grid.setHgap(10);
                grid.setVgap(10);
                grid.setPadding(new Insets(25, 25, 25, 25));

                grid.add(usernameLabel, 0, 0);
                grid.add(nameLabel, 0, 1);
                grid.add(emailLabel, 0, 2);
                grid.add(phoneLabel, 0, 3);
                grid.add(passwordField, 0, 4);
                grid.add(showPasswordButton, 0, 5);
                grid.add(backButton, 0, 6);
                grid.add(editButton, 1, 6);

                passwordField.setVisible(false);

                showPasswordButton.setOnAction(e -> {
                    passwordField.setVisible(showPasswordButton.isSelected());
                });

                backButton.setOnAction(e -> showMainPage());
                editButton.setOnAction(e -> showChangePasswordPage());

                Scene scene = new Scene(grid, 1000, 700);
                primaryStage.setScene(scene);
                primaryStage.show();
            } else {
                showAlert("Customer not found!", "");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showChangePasswordPage() {
        GridPane grid = new GridPane();
        grid.setAlignment(javafx.geometry.Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Scene scene = new Scene(grid, 1000, 700);
        primaryStage.setScene(scene);

        PasswordField newPasswordField = new PasswordField();
        PasswordField reEnterPasswordField = new PasswordField();
        Button saveButton = new Button("Simpan");

        grid.add(new Label("New Password:"), 0, 0);
        grid.add(newPasswordField, 1, 0);
        grid.add(new Label("Re-enter Password:"), 0, 1);
        grid.add(reEnterPasswordField, 1, 1);
        grid.add(saveButton, 1, 2);

        saveButton.setOnAction(e -> {
            String newPassword = newPasswordField.getText();
            String reEnterPassword = reEnterPasswordField.getText();

            if (newPassword.length() < 8) {
                showAlert("Pasword minimum 8 Characters!", "");
            } else if (!newPassword.equals(reEnterPassword)) {
                showAlert("Password doesn't match!", "");
            } else {
                
                updateCustomerPassword(newPassword);
                showAlert("Password has been successfully updated!", "");
                showCustomerProfile();
            }
        });

        primaryStage.show();
    }
    
    private void updateCustomerPassword(String newPassword) {
        String query = "UPDATE customer SET Password = ? WHERE Username = ?";
        
        try (PreparedStatement preparedStatement = connect.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, newPassword);
            preparedStatement.setString(2, currentUser);
            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                showAlert("Password has been successfully updated!", "");
            } else {
                showAlert("Failed to update password", "");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    private void showCustomerSignInPage() {
    	GridPane grid = new GridPane();
        Image backgroundImage = new Image("file:Customersigninpage.png"); 
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        grid.setBackground(new Background(background));
        grid.setAlignment(javafx.geometry.Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Scene scene = new Scene(grid, 1000, 700);
        primaryStage.setScene(scene);

        TextField usernameTextField = new TextField();
        PasswordField passwordField = new PasswordField();
        Button signInButton = new Button("Sign In");
        Button backButton = new Button("Back");

        grid.add(new Label("Username:"), 0, 0);
        grid.add(usernameTextField, 1, 0);
        grid.add(new Label("Password:"), 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(signInButton, 1, 2);
        grid.add(backButton, 0, 2);

        signInButton.setOnAction(e -> {
            String username = usernameTextField.getText();
            String password = passwordField.getText();

            if (isValidCustomerCredentials(username, password)) {
                currentUser = username;
                showAlert("Successfully signed in! ", "");
                showMainPage();
            } else {
                showAlert("Username or password incorrect!", "");
            }
        });
        backButton.setOnAction(e -> showSignInPage());
        primaryStage.show();
    }
    
    private boolean isValidCustomerCredentials(String username, String password) {
        String query = "SELECT * FROM customer WHERE Username = ? AND Password = ?";
        try (PreparedStatement preparedStatement = connect.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next(); 
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void clearFields(TextField nameTextField, TextField phoneTextField, TextField emailTextField,
            TextField usernameTextField, PasswordField passwordField, PasswordField rePasswordField) {
nameTextField.clear();
phoneTextField.clear();
emailTextField.clear();
usernameTextField.clear();
passwordField.clear();
rePasswordField.clear();
}

    private void showStaffSignInPage() {
        GridPane grid = new GridPane();
        Image backgroundImage = new Image("file:staffsigninpage.png"); 
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        grid.setBackground(new Background(background));
        grid.setAlignment(javafx.geometry.Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Scene scene = new Scene(grid, 1000, 700);
        primaryStage.setScene(scene);

        TextField staffIdTextField = new TextField();
        PasswordField passwordField = new PasswordField();
        Button signInButton = new Button("Sign In");
        Button backButton = new Button("Back");

        grid.add(new Label("StaffID:"), 0, 0);
        grid.add(staffIdTextField, 1, 0);
        grid.add(new Label("Password:"), 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(signInButton, 1, 2);
        grid.add(backButton, 0, 2);

        signInButton.setOnAction(e -> {
            String staffId = staffIdTextField.getText();
            String password = passwordField.getText();
            currentStaff = new Staff(staffId, getStaffName(getStaffIndex(staffId)));

            if (isValidStaffCredentials(password)) {
                currentUser = staffId;
                showAlert("Welcome", currentStaff.getName());
                showStaffMainPage();
            } else {
                showAlert("Invalid StaffID or password", "");
            }
        });
        backButton.setOnAction(e -> showSignInPage());
        primaryStage.show();
    }
    
    private boolean isValidStaffCredentials(String password) {
        return currentStaff != null && currentStaff.isValidCredentials(password);
    }
       
    private void showStaffMainPage() {
        VBox vbox = new VBox(10); 
        
        Image backgroundImage = new Image("file:staffmainpage.png"); 
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        vbox.setBackground(new Background(background));
        vbox.setAlignment(Pos.CENTER);

        Scene scene = new Scene(vbox, 1000, 700);
        primaryStage.setScene(scene);

        Button backButton = new Button("Back");
        Button kampanyeButton = new Button("Campaign");

        Label welcomeLabel = new Label();
        String welcomeText = "Welcome, " + currentStaff.getName();
        autoTypeLabel(welcomeLabel, welcomeText);
        

        HBox buttonsBox = new HBox(10); 
        buttonsBox.setAlignment(Pos.CENTER);
        buttonsBox.getChildren().addAll(backButton, kampanyeButton);

        vbox.getChildren().addAll(welcomeLabel, buttonsBox);

        backButton.setOnAction(e -> showSignInPage());
        kampanyeButton.setOnAction(e -> showStaffKampanyePage());

        primaryStage.show();
    }

    
    private Timeline autoTypeLabel(Label label, String text) {
        final int[] counter = {0};
        Timeline timeline = new Timeline(new KeyFrame(
                Duration.millis(100),
                new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        if (counter[0] <= text.length()) {
                            label.setText(text.substring(0, counter[0]++));
                        } else {
                            
                        }
                    }
                }));
        timeline.setCycleCount(text.length() + 1);
        timeline.play();

        return timeline;
    }
    
	    private void showStaffKampanyePage() {
	        GridPane grid = new GridPane();
	        
	        Image backgroundImage = new Image("file:kampanye.png"); 
	        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
	        grid.setBackground(new Background(background));
	        
	        grid.setAlignment(javafx.geometry.Pos.CENTER);
	        grid.setHgap(10);
	        grid.setVgap(10);
	        grid.setPadding(new Insets(25, 25, 25, 25));
	
	        Scene scene = new Scene(grid, 1000, 700);
	        primaryStage.setScene(scene);
	
	        Button insertButton = new Button("Insert Campaign");
	        Button editButton = new Button("Edit Campaign");
	        Button viewButton = new Button("Review Campaign");
	        Button backButton = new Button("Back");
	
	        grid.add(insertButton, 0, 0);
	        grid.add(editButton, 1, 0);
	        grid.add(viewButton, 2, 0);
	        grid.add(backButton, 3, 0);
	
	        insertButton.setOnAction(e -> showRegisterKampanyePage());
	        viewButton.setOnAction(e -> viewKampanyePage());
	        editButton.setOnAction(e -> showEditKampanyePage());
	        backButton.setOnAction(e -> showStaffMainPage());
	
	        primaryStage.show();
	    }
	    
	    private void showEditKampanyePage() {
	        VBox vbox = new VBox();
	        
	        Image backgroundImage = new Image("file:editkampanye.png"); 
	        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
	        vbox.setBackground(new Background(background));
	        vbox.setAlignment(Pos.CENTER);
	        vbox.setSpacing(10);
	        vbox.setPadding(new Insets(25, 25, 25, 25));
	        Scene editScene = new Scene(vbox, 1000, 700);
	        primaryStage.setScene(editScene);

	        kampanyeTable = createKampanyeTable();
	        vbox.getChildren().addAll(kampanyeTable, createEditButtons());
	        primaryStage.show();
	    }
	    
	    private void updateKampanyeInDatabase(Kampanye kampanye) {
	        DatabaseManager dbManager = DatabaseManager.getInstance(); 

	        if (kampanye == null) {
	            System.err.println("Error: Kampanye object is null.");
	            return;
	        }

	        String query = "UPDATE kampanye SET namakampanye = ?, kapasitas = ?, deskripsiKampanye = ?, tanggal = ?, lokasi = ? WHERE IDkampanye = ?";
	        try (PreparedStatement preparedStatement = dbManager.getConnection().prepareStatement(query)) {
	            preparedStatement.setString(1, kampanye.getNamakampanye());
	            preparedStatement.setInt(2, kampanye.getKapasitas());
	            preparedStatement.setString(3, kampanye.getDeskripsiKampanye());
	            preparedStatement.setDate(4, java.sql.Date.valueOf(kampanye.getTanggal()));
	            preparedStatement.setString(5, kampanye.getLokasi());
	            preparedStatement.setString(6, kampanye.getIDkampanye());

	            System.out.println("Executing SQL Query: " + preparedStatement.toString());

	            int rowsUpdated = preparedStatement.executeUpdate();

	            System.out.println("Rows Updated: " + rowsUpdated);
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	            System.err.println("SQLException: " + ex.getMessage());
	        }
	        showStaffKampanyePage();
	    }
	    
	    private TableView<Kampanye> createKampanyeTable() {
	        TableView<Kampanye> table = new TableView<>();
	        TableColumn<Kampanye, String> idColumn = new TableColumn<>("ID");
	        idColumn.setCellValueFactory(new PropertyValueFactory<>("IDkampanye"));
	        TableColumn<Kampanye, String> nameColumn = new TableColumn<>("Name");
	        nameColumn.setCellValueFactory(new PropertyValueFactory<>("namakampanye"));
	        TableColumn<Kampanye, Integer> capacityColumn = new TableColumn<>("Capacity");
	        capacityColumn.setCellValueFactory(new PropertyValueFactory<>("kapasitas"));
	        TableColumn<Kampanye, String> descriptionColumn = new TableColumn<>("Description");
	        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("deskripsiKampanye"));
	        TableColumn<Kampanye, String> locationColumn = new TableColumn<>("Location");
	        locationColumn.setCellValueFactory(new PropertyValueFactory<>("lokasi"));
	        
	        table.getColumns().addAll(idColumn, nameColumn, capacityColumn, descriptionColumn, locationColumn);

	
	        ObservableList<Kampanye> kampanyeList = FXCollections.observableArrayList(getKampanyeListFromDatabase());
	        table.setItems(kampanyeList);
	
	        table.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
	            if (newSelection != null) {
	                handleEditButtonClick();
	            }
	        });
	
	        return table;
	    }

	    
	
	    private HBox createEditButtons() {
	        Button backButton = new Button("Back");
	        Button editButton = new Button("Edit");
	        backButton.setOnAction(e -> showStaffKampanyePage());
	        editButton.setOnAction(e -> handleEditButtonClick());
	        return new HBox(10, backButton, editButton);
	    }
	    
	    private void handleEditButtonClick() {
	        Kampanye selectedKampanye = kampanyeTable.getSelectionModel().getSelectedItem();
	        if (selectedKampanye != null) {
	            showEditKampanyeDetailsPage(selectedKampanye);
	        }
	    }
	    
	
	    private void showEditKampanyeDetailsPage(Kampanye kampanye) {
	        VBox editDetailsVBox = new VBox();
	        editDetailsVBox.setAlignment(Pos.CENTER);
	        editDetailsVBox.setSpacing(10);
	        editDetailsVBox.setPadding(new Insets(25, 25, 25, 25));

	        Scene editDetailsScene = new Scene(editDetailsVBox, 600, 400);
	        Stage editDetailsStage = new Stage();
	        editDetailsStage.setScene(editDetailsScene);

	        TextField nameTextField = new TextField(kampanye.getNamakampanye());
	        TextField capacityTextField = new TextField(String.valueOf(kampanye.getKapasitas()));
	        TextArea descriptionTextArea = new TextArea(kampanye.getDeskripsiKampanye());
	        TextField locationTextField = new TextField(kampanye.getLokasi());

	        Button saveButton = new Button("Save");
	        saveButton.setOnAction(e -> {
	            kampanye.setNamakampanye(nameTextField.getText());
	            kampanye.setKapasitas(Integer.parseInt(capacityTextField.getText()));
	            kampanye.setDeskripsiKampanye(descriptionTextArea.getText());
	            kampanye.setLokasi(locationTextField.getText());

	            updateKampanyeInDatabase(kampanye);

	            editDetailsStage.close();
	        });

	        editDetailsVBox.getChildren().addAll(
	                new Label("Edit Campaign Detail:"),
	                new Label("Name:"),
	                nameTextField,
	                new Label("Capacity:"),
	                capacityTextField,
	                new Label("Description:"),
	                descriptionTextArea,
	                new Label("Location:"),
	                locationTextField,
	                saveButton
	        );

	        editDetailsStage.show();
	    }
    
    private void viewKampanyePage() {
        GridPane grid = new GridPane();
        Image backgroundImage = new Image("file:viewkampanyestaff.png"); 
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        grid.setBackground(new Background(background));
        grid.setAlignment(javafx.geometry.Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Scene scene = new Scene(grid, 1000, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Campaign List");

        VBox layout = new VBox(10);

        Label titleLabel = new Label("Campaign List");
        grid.add(titleLabel, 0, 0, 2, 1);

        ListView<String> kampanyeListView = new ListView<>();
        kampanyeListView.getItems().clear();

        List<Kampanye> kampanyeList = getKampanyeListFromDatabase();

        for (Kampanye kampanye : kampanyeList) {
            kampanyeListView.getItems().add(kampanye.getNamakampanye());
        }

        grid.add(kampanyeListView, 0, 1, 2, 4);

        Button backButton = new Button("Back");
        Button viewParticipantsButton = new Button("View Participants");

        backButton.setOnAction(e -> showStaffMainPage());

        viewParticipantsButton.setOnAction(e -> {
            String selectedKampanyeName = kampanyeListView.getSelectionModel().getSelectedItem();
            if (selectedKampanyeName != null) {
                viewParticipants(selectedKampanyeName);
            } else {
                showAlert("Choose Campaign", "Please choose a campaign to see participants");
            }
        });

        grid.add(backButton, 0, 6);
        grid.add(viewParticipantsButton, 1, 6);

        primaryStage.show();
    }
    
    private void viewParticipants(String kampanyeName) {
        List<String> participants = getParticipantsForKampanye(kampanyeName);

        GridPane participantsGrid = new GridPane();
        participantsGrid.setAlignment(javafx.geometry.Pos.CENTER);
        participantsGrid.setHgap(10);
        participantsGrid.setVgap(10);
        participantsGrid.setPadding(new Insets(25, 25, 25, 25));

        Stage participantsStage = new Stage(); 
        Scene participantsScene = new Scene(participantsGrid, 1000, 700);
        participantsStage.setScene(participantsScene);
        participantsStage.setTitle("Campaign Participants");

        Label participantsLabel = new Label("Campaign Participants : " + kampanyeName);
        participantsGrid.add(participantsLabel, 0, 0, 2, 1);

        ListView<String> participantsListView = new ListView<>();
        participantsListView.getItems().addAll(participants);

        participantsGrid.add(participantsListView, 0, 1, 2, 4);

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> {
            participantsStage.close();  
            showStaffMainPage();
        });

        participantsGrid.add(backButton, 0, 6);

        participantsStage.show();  
    }
    
    private List<String> getParticipantsForKampanye(String kampanyeName) {
        List<String> participants = new ArrayList<>();

        try (Connection connection = connect.getConnection()) {
            String query = "SELECT username FROM formregistrasikampanye WHERE idKampanye = (SELECT IDkampanye FROM kampanye WHERE namakampanye = ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, kampanyeName);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String username = resultSet.getString("username");
                        participants.add(username);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        
        return participants;
    }
    
    
    
    private void showRegisterKampanyePage() {
        GridPane grid = new GridPane();
        
        Image backgroundImage = new Image("file:insertkampanye.png"); 
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        grid.setBackground(new Background(background));
        
        grid.setAlignment(javafx.geometry.Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Scene scene = new Scene(grid, 1000, 700);
        primaryStage.setScene(scene);

        Label nameLabel = new Label("Campaign Name:");
        TextField nameTextField = new TextField();

        Label kapasitasLabel = new Label("Capacity:");
        Spinner<Integer> kapasitasSpinner = new Spinner<>(20, 100, 30);

        Label deskripsiLabel = new Label("Campaign Description:");
        TextArea deskripsiTextArea = new TextArea();

        Label tanggalLabel = new Label("Date:");
        DatePicker tanggalDatePicker = new DatePicker();

        Label lokasiLabel = new Label("Location:");
        TextField lokasiTextField = new TextField();

        Button submitButton = new Button("Submit");
        
       
        Button backButton = new Button("Back");

        grid.add(nameLabel, 0, 0);
        grid.add(nameTextField, 1, 0);
        grid.add(kapasitasLabel, 0, 1);
        grid.add(kapasitasSpinner, 1, 1);
        grid.add(deskripsiLabel, 0, 2);
        grid.add(deskripsiTextArea, 1, 2);
        grid.add(tanggalLabel, 0, 3);
        grid.add(tanggalDatePicker, 1, 3);
        grid.add(lokasiLabel, 0, 4);
        grid.add(lokasiTextField, 1, 4);
        grid.add(submitButton, 1, 5);
        grid.add(backButton, 2, 5);

        backButton.setOnAction(e -> {
            showStaffKampanyePage();
        });
        submitButton.setOnAction(e -> {
            
            if (isNullOrEmpty(nameTextField.getText()) || deskripsiTextArea.getText().isEmpty()
                    || tanggalDatePicker.getValue() == null || isNullOrEmpty(lokasiTextField.getText())) {
                showAlert("All fields must be filled!", "Please fill in all the required fields.");
                return;
            }

            
            String namaKampanye = nameTextField.getText();
            int kapasitas = kapasitasSpinner.getValue();
            String deskripsi = deskripsiTextArea.getText();
            LocalDate tanggal = tanggalDatePicker.getValue();
            String lokasi = lokasiTextField.getText();
            Random random = new Random();
            
            String idKampanye = "KMP" + random.nextInt(10) + random.nextInt(10) + random.nextInt(10)  ;
            

            insertKampanye(idKampanye, namaKampanye, kapasitas, deskripsi, tanggal, lokasi);
            showAlert("Campaign successfully registered!", "");

            
        });

        primaryStage.show();
    }
    
    private void insertKampanye(String idKampanye, String namaKampanye, int kapasitas, String deskripsi, LocalDate tanggal, String lokasi) {
        String query = "INSERT INTO kampanye (IDkampanye, namakampanye, kapasitas, deskripsiKampanye, tanggal, lokasi) " +
                       "VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connect.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, idKampanye);
            preparedStatement.setString(2, namaKampanye);
            preparedStatement.setInt(3, kapasitas);
            preparedStatement.setString(4, deskripsi);
            preparedStatement.setDate(5, Date.valueOf(tanggal));
            preparedStatement.setString(6, lokasi);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            
        }
    }

    private boolean isNullOrEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }


    private boolean isNewUser(String username) {
        return true;
    }

    private boolean isValidStaffCredentials(int index, String password) {
        String[] passwords = {"gueganteng", "ngikngok", "gakmauah", "walauwee"};
        return passwords[index].equals(password);
    }

    private int getStaffIndex(String staffId) {
        String[] staffIds = {"ST001", "ST002", "ST003", "ST004"};
        for (int i = 0; i < staffIds.length; i++) {
            if (staffIds[i].equals(staffId)) {
                return i;
            }
        }
        return -1;
    }

    private String getStaffName(int index) {
        String[] staffNames = {"Sean", "Angie", "Lynn", "Pugger"};
        return staffNames[index];
    }

    private void showAlert(String message, String staffName) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message + " " + staffName);
        alert.showAndWait();
    }

    private void showPetaLingkunganPage() {
        GridPane grid = new GridPane();
        Image backgroundImage = new Image("file:petalingkungan.png"); 
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        grid.setBackground(new Background(background));
        grid.setAlignment(javafx.geometry.Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Scene scene = new Scene(grid, 1000, 700);
        primaryStage.setScene(scene);

        Label locationLabel = new Label("Location:");
        ComboBox<String> locationDropdown = new ComboBox<>();
        locationDropdown.getItems().addAll(
                "Nanggroe Aceh Darussalam (Ibu Kota Banda Aceh)",
                "Sumatera Utara (Ibu Kota Medan)",
                "Sumatera Selatan (Ibu Kota Palembang)",
                "Sumatera Barat (Ibu Kota Padang)",
                "Bengkulu (Ibu Kota Bengkulu)",
                "Riau (Ibu Kota Pekanbaru)",
                "Kepulauan Riau (Ibu Kota Tanjung Pinang)",
                "Jambi (Ibu Kota Jambi)",
                "Lampung (Ibu Kota Bandar Lampung)",
                "Bangka Belitung (Ibu Kota Pangkal Pinang)",
                "Kalimantan Barat (Ibu Kota Pontianak)",
                "Kalimantan Timur (Ibu Kota Samarinda)",
                "Kalimantan Selatan (Ibu Kota Banjarbaru)",
                "Kalimantan Tengah (Ibu Kota Palangkaraya)",
                "Kalimantan Utara (Ibu Kota Tanjung Selor)",
                "Banten (Ibu Kota Serang)",
                "DKI Jakarta (Ibu Kota Jakarta)",
                "Jawa Barat (Ibu Kota Bandung)",
                "Jawa Tengah (Ibu Kota Semarang)",
                "Daerah Istimewa Yogyakarta (Ibu Kota Yogyakarta)",
                "Jawa Timur (Ibu Kota Surabaya)",
                "Bali (Ibu Kota Denpasar)",
                "Nusa Tenggara Timur (Ibu Kota Kupang)",
                "Nusa Tenggara Barat (Ibu Kota Mataram)",
                "Gorontalo (Ibu Kota Gorontalo)",
                "Sulawesi Barat (Ibu Kota Mamuju)",
                "Sulawesi Tengah (Ibu Kota Palu)",
                "Sulawesi Utara (Ibu Kota Manado)",
                "Sulawesi Tenggara (Ibu Kota Kendari)",
                "Sulawesi Selatan (Ibu Kota Makassar)",
                "Maluku Utara (Ibu Kota Sofifi)",
                "Maluku (Ibu Kota Ambon)",
                "Papua Barat (Ibu Kota Manokwari)",
                "Papua (Ibu Kota Jayapura)",
                "Papua Tengah (Ibu Kota Nabire)",
                "Papua Pegunungan (Ibu Kota Jayawijaya)",
                "Papua Selatan (Ibu Kota Merauke)",
                "Papua Barat Daya (Ibu Kota Sorong)"
        );

        Label categoryLabel = new Label("Category:");
        ComboBox<String> categoryDropdown = new ComboBox<>();
        categoryDropdown.getItems().addAll("Bank Sampah", "E-Waste", "Eco Brick", "Food and Beverage");

        Button searchButton = new Button("Search");
        Button backButton = new Button("Back");
        Button historyButton = new Button("History");

        grid.add(locationLabel, 0, 0);
        grid.add(locationDropdown, 1, 0);
        grid.add(categoryLabel, 0, 1);
        grid.add(categoryDropdown, 1, 1);
        grid.add(searchButton, 1, 2);
        grid.add(backButton, 0, 2);
        grid.add(historyButton, 2, 2);

        searchButton.setOnAction(e -> handleSearchHistory(locationDropdown, categoryDropdown));
        backButton.setOnAction(e -> showMainPage());
        historyButton.setOnAction(e -> showSearchHistory());

        primaryStage.show();
    }
    
    private void handleSearchHistory(ComboBox<String> locationDropdown, ComboBox<String> categoryDropdown) {
        String selectedLocation = locationDropdown.getValue();
        String selectedCategory = categoryDropdown.getValue();

        if (selectedLocation == null && selectedCategory == null) {
            showAlert("Please choose category and location!", "");
        } else if (selectedLocation == null) {
            showAlert("Please choose location!", "");
        } else if (selectedCategory == null) {
            showAlert("Please choose category!", "");
        } else {
            String searchResult = "Location: " + selectedLocation + ", Category: " + selectedCategory;

            Random random = new Random();
            
            String id = "SH" + random.nextInt(10) + random.nextInt(10) + random.nextInt(10);
            
            insertSearchHistory(id,currentUser, searchResult);

            showAlert("Search result: ", searchResult);
        }
    }
    
    private void insertSearchHistory(String id, String username, String searchResult) {
        String query = "INSERT INTO search_history (id, username, search_result) VALUES (?, ?, ?)";
        
        try (PreparedStatement preparedStatement = connect.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, id);
            preparedStatement.setString(2, username);
            preparedStatement.setString(3, searchResult);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showSearchHistory() {
        String query = "SELECT * FROM search_history WHERE username = ?";

        try (PreparedStatement preparedStatement = connect.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, currentUser);
            ResultSet resultSet = preparedStatement.executeQuery();

            List<String> history = new ArrayList<>();
            while (resultSet.next()) {
                String searchResult = resultSet.getString("search_result");
                Timestamp timestamp = resultSet.getTimestamp("search_timestamp");
                history.add(searchResult + " (Timestamp: " + timestamp + ")");
            }

            if (history.isEmpty()) {
                showAlert("No search history!", "");
            } else {
                String historyMessage = String.join("\n", history);
                showAlert("Search History", "User: " + currentUser + "\n" + historyMessage);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}